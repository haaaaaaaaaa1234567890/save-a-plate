// --- Firebase Configuration ---
const firebaseConfig = {
    apiKey: "AIzaSyATBgM1-ImYKo2B8w3WNX9I5rQMTb--6lY",
    authDomain: "save-a-plate-save-a-life.firebaseapp.com",
    projectId: "save-a-plate-save-a-life",
    databaseURL: "https://save-a-plate-save-a-life-default-rtdb.asia-southeast1.firebasedatabase.app/",
    storageBucket: "save-a-plate-save-a-life.appspot.com",
    messagingSenderId: "554589525407",
    appId: "1:554589525407:web:5cb99d2b5ac9cdc865d9aa"
};


// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const storage = firebase.storage();

// --- Slide Navigation ---
function goToSlide(id) {
    document.querySelectorAll('.slide').forEach(slide => {
        slide.classList.remove('active');
    });
    document.getElementById(id).classList.add('active');
}

// --- Amazon Redirect ---
function redirectToShop() {
    const item = document.getElementById('buyInput').value.trim();
    if (item) {
        window.open(`https://www.amazon.in/s?k=${encodeURIComponent(item)}`, '_blank');
    }
}

// --- Pledge System & Leaderboard ---
window.submitPledge = function() {
    const regionSelect = document.getElementById("region");
    const region = regionSelect.value;
    if (!region) {
        alert("Please select your region before pledging.");
        return;
    }
    if (localStorage.getItem('hasPledged')) {
        alert("Thank you, but it looks like you've already pledged from this device! 🙏");
        return;
    }
    const regionRef = db.ref("pledges/" + region);
    regionRef.transaction((currentValue) => {
        return (currentValue || 0) + 1;
    }).then(() => {
        alert("Thank you for your pledge! Your support makes a difference. 🌱");
        localStorage.setItem('hasPledged', 'true');
    }).catch((error) => {
        console.error("Pledge transaction failed: ", error);
        alert("Sorry, there was an error submitting your pledge.");
    });
};

function updateLeaderboard() {
    const list = document.getElementById("regionLeaderboard");
    const pledgesRef = db.ref("pledges");
    pledgesRef.on("value", (snapshot) => {
        const data = snapshot.val();
        if (!data) {
            list.innerHTML = "<li>No pledges yet. Be the first!</li>";
            return;
        }
        const sortedRegions = Object.entries(data).sort((a, b) => b[1] - a[1]);
        list.innerHTML = "";
        sortedRegions.forEach(([region, count]) => {
            const li = document.createElement("li");
            li.textContent = `🌍 ${region}: ${count} pledges`;
            list.appendChild(li);
        });
    });
}

// --- Modal & Tip of the Day ---
const tips = [
    "Store leftovers in clear containers so you don’t forget them.",
    "Plan meals ahead to avoid overbuying.",
    "Compost food scraps instead of tossing them.",
    "Use vegetable peels for broth or stir-fry.",
    "Freeze excess food before it spoils."
];

function showModalTip() {
    const tip = tips[Math.floor(Math.random() * tips.length)];
    document.getElementById('dailyTip').textContent = tip;
    document.getElementById('myModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('myModal').style.display = 'none';
}

function closeOwnershipModal() {
    document.getElementById("ownershipModal").style.display = "none";
}


// --- Chart.js Setup ---
const ctx = document.getElementById("foodChart").getContext("2d");
new Chart(ctx, {
    type: "bar",
    data: {
        labels: ["Food Produced", "Food Wasted"],
        datasets: [{
            label: "Billions of Tons",
            data: [4, 1.3],
            backgroundColor: ["#0c4f2b", "#ff595e"],
            borderColor: ["#0c4f2b", "#ff595e"],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// --- Stats Update ---
document.getElementById('production').textContent = '10';
document.getElementById('wasted').textContent = '1.3';
document.getElementById('hungry').textContent = '828';


// --- **FIXED** Populate Indian States/UTs ---
function populateIndianStates() {
    const indianStates = [
        "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
        "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa",
        "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
        "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
        "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
        "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
    ];

    const stateSelect = document.getElementById('state');
    // Remove the country dropdown and its label if they exist
    const countrySelect = document.getElementById('country');
    if (countrySelect) {
        countrySelect.parentElement.removeChild(countrySelect.previousElementSibling); // remove label
        countrySelect.parentElement.removeChild(countrySelect); // remove select
    }

    stateSelect.innerHTML = '<option disabled selected value="">Select State/UT</option>'; // Add a default option
    indianStates.forEach(state => {
        const opt = document.createElement('option');
        opt.value = state;
        opt.textContent = state;
        stateSelect.appendChild(opt);
    });
}


// --- **FIXED** Volunteer Registration Form Handler ---
document.getElementById('volunteerForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const volunteerData = {
        name: event.target.name.value,
        email: event.target.email.value,
        contact: event.target.contact.value,
        location: event.target.location.value,
        address: event.target.address.value,
        timestamp: new Date().toISOString()
    };

    // Push data to Firebase Realtime Database
    db.ref('volunteers').push(volunteerData)
        .then(() => {
            alert('✅ Thank you for registering as a volunteer! We will contact you soon.');
            event.target.reset(); // Clear the form
        })
        .catch(error => {
            console.error('Error registering volunteer:', error);
            alert('❌ An error occurred. Please try again.');
        });
});


// --- **ADDED** Hunger Report Form Handler ---
document.getElementById('hungerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const submitButton = event.target.querySelector('button[type="submit"]');
    submitButton.disabled = true; // Disable button to prevent multiple submissions
    submitButton.textContent = 'Uploading...';

    const file = event.target.media.files[0];
    const hungryCount = event.target.hungryCount.value;
    const email = event.target.email.value;
    const state = event.target.state.value;

    if (!file) {
        alert("Please upload a photo or video.");
        submitButton.disabled = false;
        submitButton.textContent = '📤 Submit Report';
        return;
    }

    // Create a unique filename for storage
    const storageRef = storage.ref('reports/' + new Date().getTime() + '_' + file.name);
    const uploadTask = storageRef.put(file);

    // Handle the upload process
    uploadTask.on('state_changed',
        (snapshot) => { /* You can add progress bar logic here if needed */ },
        (error) => {
            console.error("Upload failed:", error);
            alert("❌ File upload failed. Please try again.");
            submitButton.disabled = false;
            submitButton.textContent = '📤 Submit Report';
        },
        () => {
            // On successful upload, get the download URL
            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                const reportData = {
                    hungryCount: hungryCount,
                    reporterEmail: email,
                    location: state,
                    mediaUrl: downloadURL,
                    timestamp: firebase.database.ServerValue.TIMESTAMP
                };

                // Save the report details to the Realtime Database
                db.ref('hungerReports').push(reportData).then(() => {
                    alert('✅ Report submitted successfully! Thank you for your help.');
                    event.target.reset();
                    goToSlide('slide4'); // Optionally redirect to a confirmation/dashboard slide
                }).catch(error => {
                    console.error("Database write failed:", error);
                    alert("❌ Failed to save report details.");
                }).finally(() => {
                    submitButton.disabled = false;
                    submitButton.textContent = '📤 Submit Report';
                });
            });
        }
    );
});


// --- Run functions on page load ---
window.onload = () => {
    showModalTip();
    updateLeaderboard();
    populateIndianStates();
    updateVolunteerList(); // <-- This line is critical!
    updateHungerReports();
    const ownershipModal = document.getElementById("ownershipModal");
    if (ownershipModal) ownershipModal.style.display = "flex";
};


function updateVolunteerList() {
    const list = document.getElementById("volunteerList");
    const volunteersRef = db.ref("volunteers");

    volunteersRef.on("value", (snapshot) => {
        const data = snapshot.val();
        list.innerHTML = ""; // Clear current list

        if (!data) {
            list.innerHTML = "<li>No volunteers yet. Be the first to join the cause! 👐</li>";
            return;
        }

        const sortedVolunteers = Object.entries(data).sort((a, b) => {
            return new Date(b[1].timestamp) - new Date(a[1].timestamp);
        });

        sortedVolunteers.forEach(([id, vol]) => {
            const li = document.createElement("li");
            li.innerHTML = `
                <div class="volunteer-card">
                    <h4>${vol.name}</h4>
                    <p><strong>📍 Location:</strong> ${vol.location}</p>
                    <p><strong>📧 Email:</strong> ${vol.email}</p>
                    <p><strong>📞 Contact:</strong> ${vol.contact}</p>
                    <p><strong>🏠 Address:</strong> ${vol.address}</p>
                </div>
            `;
            list.appendChild(li);
        });
    });
}



function updateHungerReports() {
    const reportContainer = document.getElementById("reportContainer");
    const reportsRef = db.ref("hungerReports");

    reportsRef.on("value", (snapshot) => {
        const data = snapshot.val();
        reportContainer.innerHTML = ""; // Clear previous content

        if (!data) {
            reportContainer.innerHTML = "<p>No reports yet. Be the first to report hunger. 🙏</p>";
            return;
        }

        const sortedReports = Object.entries(data).sort((a, b) => b[1].timestamp - a[1].timestamp);

        sortedReports.forEach(([id, report]) => {
            const reportBox = document.createElement("div");
            reportBox.className = "report-box";
            reportBox.innerHTML = `
                <h3>📍 Location: ${report.location}</h3>
                <p>👥 Number of Hungry People: <strong>${report.hungryCount}</strong></p>
                <p>📧 Reporter: ${report.reporterEmail}</p>
                <p>🕒 Reported At: ${new Date(report.timestamp).toLocaleString()}</p>
                <p>📎 Media: <a href="${report.mediaUrl}" target="_blank">View</a></p>
            `;
            reportContainer.appendChild(reportBox);
        });
    });
}